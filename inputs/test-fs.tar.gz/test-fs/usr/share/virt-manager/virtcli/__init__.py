# Copyright (C) 2013-2015 Red Hat, Inc.

from .cliconfig import CLIConfig
